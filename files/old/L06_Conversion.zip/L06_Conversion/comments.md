# Lesson 6 - Comments

- storing all your necessary settings in YML files
	- loading them with one line of code into a dictionary
- generating frequency lists to understand your data
	- converting frequency lists into YML files
		- (for fixing rare items, converting them into frequent items)

		